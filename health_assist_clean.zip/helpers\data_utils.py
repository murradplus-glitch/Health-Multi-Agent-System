"""
Utility functions for working with the health assistance JSON data files.
Provides caching and error handling for data access.
"""
import os
import json
import logging
from typing import Dict, List, Any, Optional
from functools import lru_cache

# Setup logging
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG_DIR = os.path.join(BASE_DIR, 'logs')
os.makedirs(LOG_DIR, exist_ok=True)

logging.basicConfig(
    filename=os.path.join(LOG_DIR, 'data_utils.log'),
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)

@lru_cache(maxsize=1)
def load_json_data(filename: str) -> dict:
    """Load JSON data from file with caching."""
    try:
        filepath = os.path.join(BASE_DIR, 'data', filename)
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
            logging.info(f"Successfully loaded {filename}")
            return data
    except FileNotFoundError:
        logging.error(f"File not found: {filename}")
        return {}
    except json.JSONDecodeError as e:
        logging.error(f"Invalid JSON in {filename}: {e}")
        return {}
    except Exception as e:
        logging.error(f"Error loading {filename}: {e}")
        return {}

def get_citizen_by_cnic(cnic: str) -> Optional[Dict[str, Any]]:
    """Find citizen record by CNIC."""
    try:
        data = load_json_data('citizens.json')
        # Handle both list and dict formats
        citizens = data if isinstance(data, list) else data.get('citizens', [])
        for citizen in citizens:
            if str(citizen.get('cnic')) == str(cnic):
                return citizen
        logging.warning(f"No citizen found with CNIC: {cnic}")
        return None
    except Exception as e:
        logging.error(f"Error looking up citizen {cnic}: {e}")
        return None

def calculate_distance(loc1: str, loc2: str) -> int:
    """
    Enhanced location matching score with city/district awareness.
    Returns:
    0 = exact match
    1 = same district/city or nearby areas
    2 = different location
    """
    if not loc1 or not loc2:
        return 2
        
    # Normalize locations
    loc1 = loc1.lower().strip()
    loc2 = loc2.lower().strip()
    
    # Direct match
    if loc1 == loc2:
        return 0
        
    # Known nearby areas/alternative names
    nearby_areas = {
        'islamabad': ['isb', 'isbd', 'islambad', 'islamabad capital'],
        'rawalpindi': ['rwp', 'pindi', 'rawalpidi', 'rawlpindi'],
        'lahore': ['lhr', 'lahore city', 'lahore district'],
    }
    
    # Normalize location names
    def normalize_location(loc):
        for main_city, variants in nearby_areas.items():
            if loc in variants or loc == main_city:
                return main_city
        return loc
        
    norm_loc1 = normalize_location(loc1)
    norm_loc2 = normalize_location(loc2)
    
    # Check normalized locations
    if norm_loc1 == norm_loc2:
        return 0
        
    # Check if locations are in twin cities
    twin_cities = {'islamabad', 'rawalpindi'}
    if norm_loc1 in twin_cities and norm_loc2 in twin_cities:
        return 1
        
    # Check if one location contains the other
    if norm_loc1 in norm_loc2 or norm_loc2 in norm_loc1:
        return 1
        
    return 2

def get_facilities_by_type(facility_type: str = None) -> List[Dict[str, Any]]:
    """Get facilities filtered by type if specified."""
    try:
        data = load_json_data('facilities.json')
        facilities = data.get('facilities', [])
        if not facility_type:
            return facilities
        return [f for f in facilities if f.get('type', '').lower() == facility_type.lower()]
    except Exception as e:
        logging.error(f"Error getting facilities: {e}")
        return []