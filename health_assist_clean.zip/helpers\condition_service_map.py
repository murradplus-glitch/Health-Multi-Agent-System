"""
Mapping from common conditions to facility service names used in the DB.
"""
CONDITION_SERVICE_MAP = {
    "pregnancy": "maternal care",
    "diabetes": "endocrinology",
    "fever": "general medicine",
    "high fever": "general medicine",
    "fever and cough": "general medicine",
    "asthma": "respiratory",
    "chest pain": "cardiology",
    "heart disease": "cardiology",
    "tuberculosis": "infectious disease",
    "kidney disease": "nephrology",
    "diarrhea": "general medicine",
    "dengue": "vector borne",
    "surgery": "surgical",
    "trauma": "emergency",
    "emergency": "emergency",
}