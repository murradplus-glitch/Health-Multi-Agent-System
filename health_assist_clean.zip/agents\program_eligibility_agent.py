"""
Program Eligibility Agent that evaluates citizen qualification for healthcare programs.
Integrates with Sehat Card eligibility checking and provides user-friendly responses.
"""

import logging
import os
from typing import Dict, Any
from helpers.sehat_helpers import check_sehat_card_eligibility
from helpers.data_utils import get_citizen_by_cnic
from helpers.retriever import Retriever
from agents.session_context import SessionContext
from helpers.response_formatter import ResponseFormatter
import re

class ProgramEligibilityAgent:
    def __init__(self):
        # Setup logging
        log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
        os.makedirs(log_dir, exist_ok=True)
        
        self.logger = logging.getLogger('program_eligibility_agent')
        self.logger.setLevel(logging.INFO)
        
        handler = logging.FileHandler(os.path.join(log_dir, 'program_eligibility_agent.log'))
        handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
        self.logger.addHandler(handler)

        # Initialize retriever for RAG-style local lookups
        self.retriever = Retriever()

    def evaluate_eligibility(self, cnic_or_session) -> Dict[str, Any]:
        """
        Evaluate a citizen's eligibility for healthcare programs using a local retriever.
        
        Args:
            cnic: Citizen's CNIC number or a search string describing the citizen
            
        Returns:
            Dictionary with eligibility status and formatted message
        """
        try:
            # Accept either a CNIC string or a SessionContext
            if isinstance(cnic_or_session, SessionContext):
                cnic = cnic_or_session.cnic
            else:
                cnic = str(cnic_or_session)

            self.logger.info(f"Evaluating eligibility for identifier: {cnic}")
            # Use retriever to fetch citizen record (supports CNIC or fuzzy description)
            came_from_retriever = False
            citizen = self.retriever.get_citizen(cnic)
            if citizen:
                came_from_retriever = True
            else:
                # fallback to existing helper that reads from data files
                citizen = get_citizen_by_cnic(cnic)

            if not citizen:
                msg = f"No citizen record found for identifier {cnic}"
                self.logger.warning(msg)
                return {
                    "status": "error",
                    "message": msg,
                    "eligible": False
                }

            # Use retriever rules when available to evaluate eligibility
            rules = self.retriever.get_rules() or []
            eligible_programs = []
            reason_texts = []

            poverty_score = citizen.get('poverty_score')
            enrolled = citizen.get('enrolled', False)

            for rule in rules:
                # Rule may be structured or textual; look for numeric poverty thresholds
                threshold = None
                if isinstance(rule, dict):
                    # direct fields
                    threshold = rule.get('poverty_score_le') or rule.get('poverty_score')
                    cond_text = rule.get('condition') or rule.get('description') or ''
                else:
                    cond_text = str(rule)

                if threshold is None:
                    # try to parse from textual condition
                    m = re.search(r"(<=|at or below|less than or equal to)\s*(\d{1,4})", str(cond_text), flags=re.IGNORECASE)
                    if m:
                        try:
                            threshold = int(m.group(2))
                        except Exception:
                            threshold = None

                # If threshold based rule and citizen has a poverty_score, evaluate
                if threshold is not None and poverty_score is not None:
                    try:
                        if int(poverty_score) <= int(threshold) and not enrolled:
                            eligible_programs.append(rule)
                            reason_texts.append(f"Poverty score {poverty_score} meets rule: {cond_text}")
                    except Exception:
                        pass

            # If no programs detected via rules, fallback to existing check
            # If no programs detected via rules, fallback to existing check
            if not eligible_programs:
                ehr = check_sehat_card_eligibility(citizen.get('cnic') or citizen.get('id') or '')
                eligible = ehr.get('eligible', False)
                eligible_programs = ehr.get('eligible_programs', []) if isinstance(ehr, dict) else []
                reasons = ehr.get('reason', '') if isinstance(ehr, dict) else ''
                
                # Calculate income group and remaining credits
                income_group = "Low" if (citizen.get('poverty_score') or 100) <= 32 else "Medium"
                remaining = float(ehr.get('remaining_credit', 0))
                
                response = ResponseFormatter.format_eligibility_response(
                    eligible=eligible,
                    remaining_credits=remaining,
                    income_group=income_group,
                    raw_response=ehr,
                    language="en"
                )
                # Expose eligible_programs and message for backward compatibility with tests
                response["eligible_programs"] = eligible_programs
                response["message"] = f"{citizen.get('name','Citizen')} evaluated via fallback checker. Reasons: {reasons}"
                response["citizen_name"] = citizen.get('name')
                self.logger.info('Eligibility evaluated via fallback MCP tool')
                # Surface source for downstream consumers/tests
                response["source"] = "mcp" if not came_from_retriever else "retriever"
                return response

            # Build response using retrieved rules
            name = citizen.get('name', 'Citizen')
            masked = str(citizen.get('cnic') or citizen.get('id') or '')
            masked_cnic = (masked[:5] + '****' + masked[-4:]) if len(masked) >= 13 else masked

            message = f"{name} (CNIC {masked_cnic}) possible eligible programs: {len(eligible_programs)}."
            if reason_texts:
                message += " Reasons: " + "; ".join(reason_texts)

            # Calculate income group from poverty score
            income_group = "Low" if (citizen.get('poverty_score') or 100) <= 32 else "Medium"
            
            # Estimate remaining credits based on program rules
            base_credit = 500000  # Default annual credit limit
            used = citizen.get('credit_used', 0)
            remaining = base_credit - float(used)

            response = ResponseFormatter.format_eligibility_response(
                eligible=bool(eligible_programs),
                remaining_credits=remaining,
                income_group=income_group,
                raw_response={
                    "matched_rules": len(eligible_programs),
                    "programs": eligible_programs,
                    "reasons": reason_texts
                },
                language="en"
            )
            # Backward-compatible key expected by tests
            response["eligible_programs"] = eligible_programs
            response["citizen_name"] = name
            # Provide a human readable message preserving previous behavior/tests
            response["message"] = message

            # Surface source for downstream consumers/tests
            response["source"] = "retriever" if came_from_retriever else "mcp"

            self.logger.info(f"Eligibility evaluation completed for {masked_cnic}")
            return response

        except Exception as e:
            error_msg = f"Error evaluating eligibility: {str(e)}"
            self.logger.error(error_msg)
            return ResponseFormatter.format_eligibility_response(
                eligible=False,
                remaining_credits=0,
                income_group="Unknown",
                raw_response={"error": str(e)},
                language="en"
            )