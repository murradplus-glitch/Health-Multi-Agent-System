"""
Helper functions for Sehat Card eligibility checking and facility finding.
Uses retrieval-augmented generation with our JSON data files.
"""
import os
import json
import logging
from typing import Dict, Any, List, Optional
from .data_utils import (
    load_json_data,
    get_citizen_by_cnic,
    calculate_distance,
    get_facilities_by_type
)

# Setup logging
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG_DIR = os.path.join(BASE_DIR, 'logs')
os.makedirs(LOG_DIR, exist_ok=True)

logging.basicConfig(
    filename=os.path.join(LOG_DIR, 'sehat_helpers.log'),
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)

def check_sehat_card_eligibility(cnic: str) -> Dict[str, Any]:
    """
    Check if a citizen is eligible for Sehat Card based on their data
    and the program rules.
    
    Args:
        cnic: Citizen's CNIC number
        
    Returns:
        Dictionary with eligibility result:
        {
            "cnic": str,
            "eligible": bool,
            "reason": str,
            "details": dict  # Additional details about the decision
        }
    """
    try:
        # Get citizen data
        citizen = get_citizen_by_cnic(cnic)
        if not citizen:
            return {
                "cnic": cnic,
                "eligible": False,
                "reason": "Citizen record not found",
                "details": {"error": "CNIC not found in database"}
            }

        # Load eligibility rules
        rules = load_json_data('sehat_card_rules.json')
        if not rules:
            logging.error("Could not load Sehat Card rules")
            return {
                "cnic": cnic,
                "eligible": False,
                "reason": "System error - rules not available",
                "details": {"error": "Rules data unavailable"}
            }

        # Check rules against citizen data
        eligible = True
        reasons = []
        details = {}

        # Example rule checking (adjust based on actual rule structure)
        poverty_score = citizen.get('poverty_score')
        if poverty_score is not None:
            details['poverty_score'] = poverty_score
            if poverty_score > 30:  # Example threshold
                eligible = False
                reasons.append(f"Poverty score {poverty_score} exceeds threshold of 30")

        enrolled = citizen.get('enrolled', False)
        if enrolled:
            eligible = False
            reasons.append("Already enrolled in Sehat Card program")
        details['currently_enrolled'] = enrolled

        # Additional criteria can be checked here
        age = citizen.get('age')
        if age is not None:
            details['age'] = age
            if age < 18:
                details['note'] = "Minor - requires guardian for enrollment"

        result = {
            "cnic": cnic,
            "eligible": eligible,
            "reason": " AND ".join(reasons) if reasons else "Meets all eligibility criteria",
            "details": details
        }

        logging.info(f"Eligibility check for {cnic}: {result['eligible']}")
        return result

    except Exception as e:
        logging.error(f"Error checking eligibility for {cnic}: {e}")
        return {
            "cnic": cnic,
            "eligible": False,
            "reason": f"System error: {str(e)}",
            "details": {"error": "Internal error during eligibility check"}
        }

def find_nearest_facility(cnic: str, urgency: str) -> Dict[str, Any]:
    """
    Find the most appropriate healthcare facility for a citizen based on
    their location and the urgency level.
    
    Args:
        cnic: Citizen's CNIC number
        urgency: Level of medical urgency ("emergency", "hospital", "bhu", "routine")
        
    Returns:
        Dictionary with recommended facility and status information
    """
    try:
        # Get citizen data
        citizen = get_citizen_by_cnic(cnic)
        if not citizen:
            return {
                "status": "error",
                "message": "Citizen record not found",
                "recommended_for": cnic
            }

        citizen_location = citizen.get('location', '').lower().strip()
        if not citizen_location:
            return {
                "status": "error",
                "message": "Citizen location not available",
                "recommended_for": cnic
            }

        # Map urgency to facility types with priorities
        urgency = urgency.lower().strip()
        if urgency in ['emergency', 'critical']:
            facility_types = ['hospital']  # Only look for hospitals with emergency services
            required_services = ['emergency']
        elif urgency == 'hospital':
            facility_types = ['hospital']
            required_services = []
        elif urgency in ['bhu', 'routine', 'basic']:
            facility_types = ['bhu', 'hospital']  # Try BHU first, then hospitals
            required_services = ['primary care']
        else:
            facility_types = ['bhu', 'hospital']
            required_services = []

        # Find matching facilities
        matches = []
        
        # Get all relevant facilities
        for facility_type in facility_types:
            facilities = get_facilities_by_type(facility_type)
            
            for facility in facilities:
                if not facility.get('available', True):
                    continue
                    
                # Check for required services
                if required_services:
                    facility_services = set(s.lower() for s in facility.get('services', []))
                    if not any(req.lower() in facility_services for req in required_services):
                        continue
                
                # Calculate distance score
                distance = calculate_distance(
                    citizen_location,
                    facility.get('location', '')
                )
                
                matches.append({
                    'facility': facility,
                    'distance': distance,
                    'score': _calculate_facility_score(
                        distance=distance,
                        facility_type=facility.get('type', ''),
                        urgency=urgency,
                        has_emergency='emergency' in [s.lower() for s in facility.get('services', [])]
                    )
                })

        # Sort matches by score (higher is better)
        matches.sort(key=lambda x: (-x['score'], x['distance']))

        if matches:
            best_match = matches[0]['facility']
            distance = matches[0]['distance']
            
            result = {
                "status": "success",
                "facility_id": best_match.get('facility_id'),
                "name": best_match.get('name'),
                "type": best_match.get('type'),
                "location": best_match.get('location'),
                "distance": "same area" if distance == 0 else 
                          "nearby" if distance == 1 else "different area",
                "distance_score": distance,
                "recommended_for": cnic,
                "services": best_match.get('services', []),
                "phone": best_match.get('phone', 'Not available'),
                "alternatives": [
                    {
                        "name": m['facility'].get('name'),
                        "type": m['facility'].get('type'),
                        "location": m['facility'].get('location'),
                        "distance": "same area" if m['distance'] == 0 else 
                                  "nearby" if m['distance'] == 1 else "different area"
                    }
                    for m in matches[1:3] if m['distance'] <= 2  # Include up to 2 nearby alternatives
                ]
            }
            
            logging.info(f"Found facility for {cnic}: {result['name']}")
            return result

        return {
            "status": "not_found",
            "message": (
                f"No suitable facilities found for {urgency} care in or near {citizen_location}. "
                "Please call emergency services if this is an emergency."
            ),
            "recommended_for": cnic
        }

    except Exception as e:
        logging.error(f"Error finding facility for {cnic}: {e}")
        return {
            "status": "error",
            "message": f"System error: {str(e)}",
            "recommended_for": cnic
        }

def _calculate_facility_score(distance: int, facility_type: str, urgency: str, has_emergency: bool) -> float:
    """Calculate a score for facility matching. Higher is better."""
    score = 0.0
    
    # Distance is most important
    score += (3 - distance) * 10  # 20 for same area, 10 for nearby, 0 for far
    
    # Facility type matching
    if urgency in ['emergency', 'critical']:
        if facility_type == 'hospital' and has_emergency:
            score += 15
    elif urgency == 'hospital':
        if facility_type == 'hospital':
            score += 10
    elif urgency in ['bhu', 'routine', 'basic']:
        if facility_type == 'bhu':
            score += 10
        elif facility_type == 'hospital':
            score += 5
    
    return score

# Example usage
if __name__ == '__main__':
    # Test CNIC
    test_cnic = "12345-1234567-1"
    
    # Test eligibility
    eligibility = check_sehat_card_eligibility(test_cnic)
    print("\nSehat Card Eligibility Check:")
    print(json.dumps(eligibility, indent=2))
    
    # Test facility finding
    facility = find_nearest_facility(test_cnic, "emergency")
    print("\nNearest Facility:")
    print(json.dumps(facility, indent=2))