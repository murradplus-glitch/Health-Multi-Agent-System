"""
SessionContext holds current user's CNIC and loaded profile from the retriever.
"""
from typing import Optional, Dict, Any

class SessionContext:
    def __init__(self, cnic: str, language: Optional[str] = None):
        self.cnic = str(cnic)
        self.profile: Optional[Dict[str, Any]] = None
        self.language = language  # detected language code (e.g., 'en' or 'ur')
        self.original_language = language

    def load_profile(self, retriever) -> None:
        """Load user profile from a Retriever instance."""
        if retriever:
            self.profile = retriever.get_citizen(self.cnic)
        else:
            self.profile = None
