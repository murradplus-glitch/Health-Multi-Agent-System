#!/usr/bin/env python3
"""
Minimal MCP-compatible server exposing four tools:

- triage_rules_tool(symptoms: str) -> dict
- program_eligibility_tool(profile: dict) -> dict
- facility_lookup_tool(location: str, severity: str) -> list
- reminder_store_tool(patient_id: str, message: str, due_datetime: str) -> dict

This server uses local files in `data/` and stores reminders in `data/reminders.db`.
All requests and responses are logged to `logs/mcp.log`.

Run: python mcp_server.py
"""
import os
import json
import sqlite3
import logging
from datetime import datetime, timezone
from flask import Flask, request, jsonify
from typing import List, Dict, Any

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE, 'data')
LOGS_DIR = os.path.join(BASE, 'logs')
DB_PATH = os.path.join(DATA_DIR, 'reminders.db')

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)

# Setup logging
LOG_PATH = os.path.join(LOGS_DIR, 'mcp.log')
logging.basicConfig(filename=LOG_PATH, level=logging.INFO,
                    format='%(asctime)s %(levelname)s %(message)s')

app = Flask(__name__)


def _bad_request(message: str, details: dict = None, status_code: int = 400):
    payload = {"error": message}
    if details:
        payload["details"] = details
    return jsonify(payload), status_code


def _validate_iso_datetime(s: str) -> bool:
    if not s:
        return True
    try:
        # Accept '2025-12-01T09:00:00' or with trailing Z
        if s.endswith('Z'):
            s2 = s[:-1]
        else:
            s2 = s
        datetime.fromisoformat(s2)
        return True
    except Exception:
        return False


def log_call(name: str, payload: Any, response: Any):
    logging.info('TOOL CALL: %s | payload=%s | response=%s', name, json.dumps(payload, default=str), json.dumps(response, default=str))


def load_json(fname: str):
    path = os.path.join(DATA_DIR, fname)
    if not os.path.exists(path):
        return None
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def ensure_reminders_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute('''
        CREATE TABLE IF NOT EXISTS reminders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id TEXT NOT NULL,
            message TEXT NOT NULL,
            due_datetime TEXT,
            created_at TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()


@app.route('/triage_rules_tool', methods=['POST'])
def triage_rules_tool():
    """triage_rules_tool

    Request JSON: {"symptoms": "..."}
    Response JSON: {"severity":"self-care|bhu|hospital|emergency","reasons":[...],"advice":"..."}

    Example request:
      {"symptoms":"chest pain and shortness of breath"}
    """
    if not request.is_json:
        return _bad_request('Request must be application/json')
    data = request.get_json() or {}
    symptoms = data.get('symptoms', '')
    if not isinstance(symptoms, str) or not symptoms.strip():
        return _bad_request('Field "symptoms" is required and must be a non-empty string', {"example": {"symptoms": "high fever and cough"}})
    rules = load_json('triage_rules.json') or []

    severity = 'self-care'
    reasons = []
    advice = 'Monitor symptoms. Seek care if they worsen.'

    # naive keyword matching against rules
    for r in rules:
        keywords = r.get('keywords', [])
        for kw in keywords:
            if kw.lower() in symptoms.lower():
                reasons.append(r.get('reason', kw))
                severity = r.get('severity', severity)
                advice = r.get('advice', advice)

    resp = {"severity": severity, "reasons": reasons, "advice": advice}
    log_call('triage_rules_tool', {'symptoms': symptoms}, resp)
    return jsonify(resp)


@app.route('/program_eligibility_tool', methods=['POST'])
def program_eligibility_tool():
    """program_eligibility_tool

    Request JSON: profile object (e.g. {"poverty_score": 25, "enrolled": false})
    Response JSON: {"eligible_programs": [...rule objects...]}

    Example request:
      {"poverty_score": 25, "enrolled": false}
    """
    if not request.is_json:
        return _bad_request('Request must be application/json')
    profile = request.get_json() or {}
    if not isinstance(profile, dict):
        return _bad_request('Profile must be a JSON object')
    rules = load_json('program_eligibility.json') or []

    matched = []
    for r in rules:
        # example simple rules: poverty_score <= threshold, enrolled == False
        ok = True
        if 'poverty_score_le' in r:
            ps = profile.get('poverty_score')
            if ps is None:
                ok = False
            else:
                try:
                    if float(ps) > float(r['poverty_score_le']):
                        ok = False
                except Exception:
                    ok = False
        if 'must_not_be_enrolled' in r and r['must_not_be_enrolled']:
            if profile.get('enrolled'):
                ok = False
        if ok:
            matched.append(r)

    resp = {"eligible_programs": matched}
    log_call('program_eligibility_tool', profile, resp)
    return jsonify(resp)


@app.route('/facility_lookup_tool', methods=['POST'])
def facility_lookup_tool():
    """facility_lookup_tool

    Request JSON: {"location": "city/district", "severity": "self-care|bhu|hospital|emergency"}
    Response JSON: list of facility objects (ranked)

    Example request:
      {"location":"Lahore", "severity":"hospital"}
    """
    if not request.is_json:
        return _bad_request('Request must be application/json')
    data = request.get_json() or {}
    location = data.get('location', '')
    severity = data.get('severity', '')
    if not isinstance(location, str) or not location.strip():
        return _bad_request('Field "location" is required and must be a non-empty string', {"example": {"location":"Lahore","severity":"hospital"}})
    location = location.lower()
    severity = (severity or '').lower()
    facilities = load_json('facilities.json') or []

    def score_fac(fac):
        score = 0
        # prefer matching location
        if any(location in str(v).lower() for v in fac.values() if isinstance(v, str)):
            score += 50
        # prefer larger facilities or those mentioning services
        if fac.get('type') and severity in fac.get('type', '').lower():
            score += 20
        if fac.get('services') and severity in ' '.join(fac.get('services', [])).lower():
            score += 10
        # available flag
        if fac.get('available') in [True, 'yes', 'Yes', 'YES']:
            score += 5
        return score

    scored = [(score_fac(f), f) for f in facilities]
    scored.sort(key=lambda x: x[0], reverse=True)
    results = [f for s, f in scored[:10]]

    log_call('facility_lookup_tool', {'location': location, 'severity': severity}, results)
    return jsonify(results)


@app.route('/reminder_store_tool', methods=['POST'])
def reminder_store_tool():
    payload = request.get_json() or {}
    patient_id = payload.get('patient_id')
    message = payload.get('message')
    due = payload.get('due_datetime')

    if not patient_id or not message:
        resp = {'error': 'patient_id and message are required'}
        log_call('reminder_store_tool', payload, resp)
        return jsonify(resp), 400
    # validate due_datetime if present
    if due and not isinstance(due, str):
        return _bad_request('Field "due_datetime" must be an ISO datetime string if provided')
    if due and not _validate_iso_datetime(due):
        return _bad_request('Field "due_datetime" is not a valid ISO datetime string', {"example": "2025-12-01T09:00:00Z"})
    ensure_reminders_db()
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    # Use timezone-aware UTC timestamp with Z suffix (ISO 8601 format)
    created = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
    cur.execute('INSERT INTO reminders (patient_id, message, due_datetime, created_at) VALUES (?, ?, ?, ?)',
                (patient_id, message, due, created))
    conn.commit()
    rid = cur.lastrowid
    conn.close()

    entry = {"id": rid, "patient_id": patient_id, "message": message, "due_datetime": due, "created_at": created}
    log_call('reminder_store_tool', payload, entry)
    return jsonify(entry)


if __name__ == '__main__':
    # Simple run
    print("Starting MCP-compatible server on http://127.0.0.1:5000")
    app.run(host='127.0.0.1', port=5000)
