"""Simple RAG-style retriever over local JSON data files.

Provides convenience methods to fetch citizen records, facility records,
and rules from the 'data/' folder. This is a light-weight retriever tailored
for local development and testing (no external vector DB).
"""
from typing import Any, Dict, List, Optional
import re
from helpers.data_utils import load_json_data, calculate_distance


class Retriever:
    def __init__(self):
        # Load raw JSON data (may be dicts or lists depending on file)
        self._citizens_raw = load_json_data('citizens.json') or {}
        self._facilities_raw = load_json_data('facilities.json') or []
        self._rules_raw = load_json_data('sehat_card_rules.json') or {}

        # Normalize common access
        if isinstance(self._citizens_raw, dict) and 'citizens' in self._citizens_raw:
            self.citizens = self._citizens_raw.get('citizens', [])
        elif isinstance(self._citizens_raw, list):
            self.citizens = self._citizens_raw
        else:
            # try to extract list from dict
            self.citizens = []
            if isinstance(self._citizens_raw, dict):
                for v in self._citizens_raw.values():
                    if isinstance(v, list):
                        self.citizens = v
                        break

        if isinstance(self._facilities_raw, list):
            self.facilities = self._facilities_raw
        elif isinstance(self._facilities_raw, dict) and 'facilities' in self._facilities_raw:
            self.facilities = self._facilities_raw.get('facilities', [])
        else:
            self.facilities = []

        # Rules may be object or list
        if isinstance(self._rules_raw, dict) and 'rules' in self._rules_raw:
            r = self._rules_raw['rules']
            if isinstance(r, list):
                self.rules = r
            elif isinstance(r, dict):
                # convert mapping to list
                self.rules = []
                for k, v in r.items():
                    if isinstance(v, dict):
                        self.rules.append(v)
                    else:
                        self.rules.append({'id': k, 'description': v})
        elif isinstance(self._rules_raw, list):
            self.rules = self._rules_raw
        else:
            self.rules = []

    def get_citizen(self, identifier: str) -> Optional[Dict[str, Any]]:
        """Retrieve a citizen by CNIC or by name/description fuzzy match.

        If `identifier` matches a CNIC pattern it performs an exact lookup.
        Otherwise it does a case-insensitive substring search on name and city.
        """
        if not identifier:
            return None

        identifier = identifier.strip()
        # CNIC pattern 12345-1234567-1
        if re.match(r"^\d{5}-\d{7}-\d{1}$", identifier):
            for c in self.citizens:
                if str(c.get('cnic') or c.get('id') or '') == identifier:
                    return c

        # try to match by CNIC label variants
        m = re.search(r"(\d{5}-\d{7}-\d{1})", identifier)
        if m:
            code = m.group(1)
            for c in self.citizens:
                if str(c.get('cnic') or c.get('id') or '') == code:
                    return c

        # fallback: substring search on name or city
        low = identifier.lower()
        for c in self.citizens:
            name = str(c.get('name') or '').lower()
            city = str(c.get('location') or c.get('city') or '').lower()
            phone = str(c.get('phone') or '').lower()
            if low in name or low in city or low in phone:
                return c

        # no match
        return None

    def get_rules(self) -> List[Dict[str, Any]]:
        return self.rules

    def find_facilities(self, location: str, required_services: Optional[List[str]] = None, allow_global: bool = True) -> List[Dict[str, Any]]:
        """Retrieve facilities matching location and services with smart fallback.

        Args:
            location: City/area to search in, or empty for global search
            required_services: List of required services to filter by
            allow_global: If True and no local matches found, will search globally

        Returns:
            List of facility dicts ranked by proximity and filtered by services.
            If allow_global=True and no local matches found with required services,
            returns global matches. If allow_global=False, returns empty list when
            no local matches found.
        """
        def filter_by_services(facilities: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
            """Helper to filter facilities by required services"""
            if not required_services:
                return facilities
            reqs = [s.lower() for s in required_services]
            filtered = []
            for f in facilities:
                services = [str(s).lower() for s in f.get('services') or []]
                if any(r in ' '.join(services) for r in reqs):
                    filtered.append(f)
            return filtered

        # First try local search if location provided
        if location:
            loc_low = location.lower().strip()
            local_candidates = []
            for f in self.facilities:
                f_location = str(f.get('location') or f.get('city') or '').lower().strip()
                # Match either exact location or as part of city name
                if loc_low == f_location or loc_low in f_location.split():
                    local_candidates.append(f)
            
            # Filter local candidates by services
            local_matches = filter_by_services(local_candidates)
            if local_matches:
                candidates = local_matches
            elif not required_services:
                # No service requirements, use all local matches
                candidates = local_candidates
            elif allow_global:
                # No local matches with required services, try global search
                global_matches = filter_by_services(self.facilities)
                if global_matches:
                    candidates = global_matches
                else:
                    return []  # No matches anywhere with required services
            else:
                return []  # No local matches with required services
        else:
            # Global search requested directly
            candidates = filter_by_services(self.facilities)
            if not candidates:
                return []

        # rank by calculate_distance if possible
        ranked = []
        for f in candidates:
            try:
                dist = calculate_distance(location or '', f.get('location') or '')
                ranked.append((dist, f))
            except Exception:
                ranked.append((999, f))

        ranked.sort(key=lambda x: x[0])
        return [f for _, f in ranked]
