# Health Assist — PDF Extractor & Minimal MCP Server

This workspace contains two main artifacts:

- `pdf_extract.py` — extracts structured data (Citizens, Facilities, Sehat Card Rules) from `Mock Data for Sehat Card Agent.pdf` and prints JSON to stdout.
- `mcp_server.py` — a minimal MCP-compatible HTTP server exposing four tools backed by local JSON files and SQLite.

Requirements
- Python 3.8+
- Install dependencies:

```powershell
python -m pip install -r requirements.txt
```

How to run the PDF extractor

1. Put `Mock Data for Sehat Card Agent.pdf` in the project root (same folder as `pdf_extract.py`).
2. Run:

```powershell
python pdf_extract.py
```

This will print a JSON object with keys `citizens`, `facilities`, and `rules`.

How to run the MCP server

```powershell
python mcp_server.py
```

The server listens on http://127.0.0.1:5000 and exposes POST endpoints:

- `/triage_rules_tool` -> payload: {"symptoms": "..."}
- `/program_eligibility_tool` -> payload: profile object (JSON)
- `/facility_lookup_tool` -> payload: {"location": "...", "severity": "..."}
- `/reminder_store_tool` -> payload: {"patient_id":"...","message":"...","due_datetime":"ISO string"}

All calls and responses are logged to `logs/mcp.log`.

Notes
- No cloud dependencies. All data is local in `data/`.
- `data/facilities.json`, `data/citizens.json`, and `data/sehat_card_rules.json` are expected to exist (sample files may already be present in the workspace). The server also uses `data/triage_rules.json` and `data/program_eligibility.json` which are included.
