"""Router for serving mock responses in UI testing mode."""

import os
import json
from typing import Dict, Any, Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

class MockResponseConfig:
    """Configuration for mock response behavior."""
    def __init__(self):
        self.enabled = os.getenv('MOCK_MODE', '').lower() in ('true', '1', 'yes')
        self.responses_file = os.path.join(
            os.path.dirname(os.path.dirname(__file__)), 
            'data', 
            'mock_responses.json'
        )
        self._responses: Optional[Dict[str, Any]] = None

    def load_responses(self) -> Dict[str, Any]:
        """Load mock responses from JSON file."""
        if self._responses is None:
            try:
                with open(self.responses_file, 'r', encoding='utf-8') as f:
                    self._responses = json.load(f)
            except Exception as e:
                raise HTTPException(
                    status_code=500,
                    detail=f"Failed to load mock responses: {str(e)}"
                )
        return self._responses

    def get_mock_response(self, query_type: str, language: str = 'en') -> Dict[str, Any]:
        """Get mock response for a query type and language."""
        responses = self.load_responses()
        if query_type not in responses:
            raise HTTPException(
                status_code=404,
                detail=f"No mock response found for query type: {query_type}"
            )
        if language not in responses[query_type]:
            raise HTTPException(
                status_code=404,
                detail=f"No {language} response found for query type: {query_type}"
            )
        return responses[query_type][language]

class ChatRequest(BaseModel):
    """Chat request model with message and patient profile."""
    message: str
    patient_profile: Dict[str, Any]

# Create router and config
router = APIRouter()
config = MockResponseConfig()
# Mount mock router handlers if enabled
@router.post("/chat", include_in_schema=True)
async def mock_chat(chat_request: ChatRequest) -> dict:
    """Mock chat endpoint that returns predefined responses."""
    try:
        # Determine query type from symptoms/message
        query_type = (
            'emergency_query' 
            if any(kw in chat_request.message.lower() for kw in 
                  ['chest pain', 'heart', 'severe', 'emergency']) 
            else 'maternity_query'
        )
        
        # Get responses for both languages
        en_response = config.get_mock_response(query_type, 'en')
        ur_response = config.get_mock_response(query_type, 'ur')
        
        return {
            "status": "success",
            "formatted_response": {
                "english": format_mock_response_english(en_response),
                "urdu": format_mock_response_urdu(ur_response)
            },
            "json_trace": en_response,  # Include full response for trace
            "degraded_mode": False
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error processing mock request: {str(e)}"
        )

def format_mock_response_english(result: Dict[str, Any]) -> str:
    """Format mock response in English."""
    sections = []
    
    # Medical Assessment
    sections.append(
        "🏥 MEDICAL ASSESSMENT:\n"
        f"Level of Care: {result.get('severity', 'Unknown').upper()}\n"
        f"Recommendation: {result.get('recommended_action', 'No specific recommendation')}"
    )
    
    # Facility Information
    if result.get('facility'):
        facility = result['facility']
        facility_text = [
            "🏥 RECOMMENDED FACILITIES:",
            f"Primary: {facility.get('name')} ({', '.join(facility.get('services', []))})",
            f"Location: {facility.get('location')}",
            f"Contact: {facility.get('phone', 'N/A')}"
        ]
        sections.append("\n".join(facility_text))
    
    # Eligibility (if present)
    if result.get('eligibility'):
        elig = result['eligibility']
        sections.append(
            "💳 PROGRAM ELIGIBILITY:\n"
            f"{elig.get('message', 'No eligibility information')}\n"
            f"Remaining Credit: {elig.get('remaining_credits', 'N/A')}"
        )
    
    return "\n\n".join(sections)

def format_mock_response_urdu(result: Dict[str, Any]) -> str:
    """Format mock response in Urdu (Roman script)."""
    sections = []
    
    # Medical Assessment
    sections.append(
        "🏥 TIBBI JAIZA:\n"
        f"Zarurat: {result.get('severity', 'Naamalom')}\n"
        f"Mashwara: {result.get('recommended_action', 'Koi khaas mashwara nahi')}"
    )
    
    # Facility Information
    if result.get('facility'):
        facility = result['facility']
        facility_text = [
            "🏥 TAJWEEZ KARDAH HASPATAL:",
            f"Haspatal: {facility.get('name')}",
            f"Maqam: {facility.get('location')}",
            f"Rabta: {facility.get('phone', 'N/A')}"
        ]
        sections.append("\n".join(facility_text))
    
    # Eligibility (if present)
    if result.get('eligibility'):
        elig = result['eligibility']
        sections.append(
            "💳 SEHAT CARD:\n"
            f"{elig.get('message', 'Koi sehat card maloomat nahi')}\n"
            f"Baqaya Credit: {elig.get('remaining_credits', 'N/A')}"
        )
    
    return "\n\n".join(sections)