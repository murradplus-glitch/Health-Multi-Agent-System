"""Shared response schema for consistent agent outputs."""

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union

class HealthResponseSchema:
    """Base schema for all agent responses."""
    def __init__(self, 
                 status: str = "success",
                 language: str = "en",
                 raw_response: Optional[Dict[str, Any]] = None):
        self.response = {
            "status": status,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "language": language,
            "raw_response": raw_response
        }

    def to_dict(self) -> Dict[str, Any]:
        """Convert response to dictionary."""
        return self.response

    def add_summary_table(self, headers: List[str], rows: List[List[str]]) -> None:
        """Add formatted markdown table to response."""
        table = "| " + " | ".join(headers) + " |\n"
        table += "|" + "|".join(["---" for _ in headers]) + "|\n"
        for row in rows:
            table += "| " + " | ".join(str(cell) for cell in row) + " |\n"
        self.response["summary_table"] = table

class EligibilityResponse(HealthResponseSchema):
    """Program eligibility response schema."""
    def __init__(self,
                 eligible: bool,
                 remaining_credits: Union[int, float],
                 income_group: str,
                 **kwargs):
        super().__init__(**kwargs)
        self.response.update({
            "eligible": eligible,
            "remaining_credits": f"PKR {remaining_credits:,.0f}",
            "income_group": income_group
        })
        self.add_summary_table(
            headers=["Category", "Details"],
            rows=[
                ["Status", "Eligible" if eligible else "Not Eligible"],
                ["Remaining Credits", f"PKR {remaining_credits:,.0f}"],
                ["Income Group", income_group]
            ]
        )

class TriageResponse(HealthResponseSchema):
    """Triage assessment response schema."""
    def __init__(self,
                 severity: str,
                 reasons: List[str],
                 recommendation: str,
                 severity_level: int = 1,
                 **kwargs):
        super().__init__(**kwargs)
        urgency_map = {
            1: "Low",
            2: "Medium",
            3: "High",
            4: "Critical"
        }
        self.response.update({
            "severity": severity,
            "severity_level": severity_level,
            "urgency": urgency_map.get(severity_level, "Unknown"),
            "reasons": reasons,
            "recommendation": recommendation
        })
        self.add_summary_table(
            headers=["Category", "Details"],
            rows=[
                ["Severity", severity],
                ["Urgency", urgency_map.get(severity_level, "Unknown")],
                ["Key Reasons", "\n".join(f"- {r}" for r in reasons)]
            ]
        )

class FacilityResponse(HealthResponseSchema):
    """Facility recommendation response schema."""
    def __init__(self,
                 facilities: List[Dict[str, Any]],
                 urgency: str,
                 recommended_action: str,
                 **kwargs):
        super().__init__(**kwargs)
        self.response.update({
            "facilities": facilities,
            "urgency": urgency,
            "recommended_action": recommended_action
        })
        
        # Create summary table with facility details
        if facilities:
            headers = ["Facility", "City", "Services", "Contact"]
            rows = []
            for f in facilities:
                services = ", ".join(f.get("services", []))
                if len(services) > 50:
                    services = services[:47] + "..."
                rows.append([
                    f.get("name", "Unknown"),
                    f.get("city", "Unknown"),
                    services,
                    f.get("phone", "N/A")
                ])
        else:
            headers = ["Message"]
            rows = [["No facilities found matching criteria"]]
            self.response["status"] = "not_found"
            
        self.add_summary_table(headers=headers, rows=rows)