"""
MCP package for Model Context Protocol functionality.
"""

from .client import MCPClient

__all__ = ['MCPClient']