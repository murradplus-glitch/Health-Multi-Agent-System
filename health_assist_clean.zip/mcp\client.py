"""
MCP (Model Context Protocol) client for making requests to the MCP server.
"""
import os
import json
import logging
import requests
from typing import Dict, Any, Optional

class MCPClient:
    """Client for interacting with the MCP server."""
    
    def __init__(self, base_url: str = "http://127.0.0.1:5000"):
        """
        Initialize the MCP client.
        
        Args:
            base_url: Base URL of the MCP server
        """
        self.base_url = base_url
        
        # Setup logging
        log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
        os.makedirs(log_dir, exist_ok=True)
        
        self.logger = logging.getLogger('mcp_client')
        self.logger.setLevel(logging.INFO)
        
        handler = logging.FileHandler(os.path.join(log_dir, 'mcp_client.log'))
        handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
        self.logger.addHandler(handler)

    def call_tool(self, tool_name: str, payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Call an MCP tool endpoint.
        
        Args:
            tool_name: Name of the tool to call
            payload: Request payload
            
        Returns:
            Response from the tool or None on failure
        """
        url = f"{self.base_url}/{tool_name}"
        self.logger.info(f"Calling MCP tool {tool_name} with payload: {json.dumps(payload)}")
        
        try:
            # First try HTTP request
            response = requests.post(url, json=payload, timeout=5)
            response.raise_for_status()
            result = response.json()
            self.logger.info(f"MCP tool {tool_name} response: {json.dumps(result)}")
            return result
            
        except Exception as e:
            # If HTTP fails, try direct Flask test client
            self.logger.warning(f"HTTP call to {tool_name} failed: {e}; trying test_client")
            try:
                from mcp_server import app as mcp_app
                with mcp_app.test_client() as client:
                    response = client.post(f"/{tool_name}", json=payload)
                    result = response.get_json()
                    if result:
                        self.logger.info(f"Got response via test_client: {json.dumps(result)}")
                        return result
                    else:
                        self.logger.error("test_client returned no JSON response")
                        return None
                        
            except Exception as ex:
                self.logger.exception(f"Both HTTP and test_client failed for {tool_name}: {ex}")
                return None