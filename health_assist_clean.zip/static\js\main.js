// Handle form submission
document.getElementById('chatForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Get message and profile data
    const message = document.getElementById('messageInput').value;
    const profile = {
        name: document.getElementById('name').value,
        cnic: document.getElementById('cnic').value,
        age: parseInt(document.getElementById('age').value),
        location: document.getElementById('location').value,
        phone: document.getElementById('phone').value,
        language: document.getElementById('language') ? document.getElementById('language').value : 'english'
    };
    
    // Validate required fields
    if (!profile.name || !profile.age || !profile.location) {
        alert('Please fill in all required profile fields');
        return;
    }

    // Optional CNIC validation: if provided it must match 12345-1234567-1
    if (profile.cnic && !/^\d{5}-\d{7}-\d{1}$/.test(profile.cnic)) {
        alert('CNIC must be in the format 12345-1234567-1');
        return;
    }

    // Phone validation: must match +92xxx-xxxxxxx
    if (!/^\+92\d{3}-\d{7}$/.test(profile.phone)) {
        alert('Phone must be in the format +92300-1234567');
        return;
    }
    
    // Show user message
    addMessage('user', message);
    
    // Clear input
    document.getElementById('messageInput').value = '';
    
    try {
        // Call backend
        const response = await fetch('/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: message,
                patient_profile: profile
            })
        });
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const data = await response.json();
        
        // Add system response: display only the selected language
        const lang = profile.language || 'english';
        const formatted = data.formatted_response || {};
        const payload = {
            text: formatted[lang] || formatted['english'] || 'No response',
        };
        addMessage('system', payload, data.json_trace, data.degraded_mode);
        
    } catch (error) {
        console.error('Error:', error);
        addMessage('system', {
            english: 'Sorry, there was an error processing your request.',
            urdu: 'Mahzrat, darkhwast par karvai karne main mushkil pesh ai.'
        });
    }
});

// Add a message to the chat
function addMessage(type, content, jsonTrace = null, degradedMode = false) {
    const messagesArea = document.getElementById('chatMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}-message`;
    
    if (type === 'user') {
        messageDiv.textContent = content;
    } else {
        // Content expected as { text: '<html or text>' }
        const body = document.createElement('div');
        body.className = 'assistant-message-body';
        // Support newline -> <br>
        body.innerHTML = (content.text || '').replace(/\n/g, '<br>');
        messageDiv.appendChild(body);
        
        // Add degraded mode warning if applicable
        if (degradedMode) {
            messageDiv.classList.add('degraded');
            const warningDiv = document.createElement('div');
            warningDiv.className = 'degraded-warning';
            warningDiv.textContent = 'System is operating in backup mode';
            messageDiv.appendChild(warningDiv);
        }
        
        // Add JSON trace button if available
        if (jsonTrace) {
            const traceButton = document.createElement('button');
            traceButton.className = 'btn btn-sm btn-outline-secondary mt-2';
            traceButton.textContent = 'View Journey Trace';
            traceButton.onclick = () => showJsonTrace(jsonTrace);
            messageDiv.appendChild(traceButton);
        }
    }
    
    messagesArea.appendChild(messageDiv);
    messagesArea.scrollTop = messagesArea.scrollHeight;
}

// Show JSON trace in modal
function showJsonTrace(jsonTrace) {
    const modal = new bootstrap.Modal(document.getElementById('jsonModal'));
    document.getElementById('jsonTrace').textContent = 
        JSON.stringify(jsonTrace, null, 2);
    modal.show();
}

// Format CNIC input
document.getElementById('cnic').addEventListener('input', function(e) {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 0) {
        if (value.length <= 5) {
            value = value;
        } else if (value.length <= 12) {
            value = value.slice(0,5) + "-" + value.slice(5);
        } else {
            value = value.slice(0,5) + "-" + value.slice(5,12) + "-" + value.slice(12,13);
        }
        e.target.value = value;
    }
});

// Format phone input
document.getElementById('phone').addEventListener('input', function(e) {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 0) {
        if (value.length <= 3) {
            value = "+92" + value;
        } else {
            value = "+92" + value.slice(0,3) + "-" + value.slice(3);
        }
        e.target.value = value;
    }
});