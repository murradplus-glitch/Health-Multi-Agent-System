"""
Streamlit UI for Sehat Card Health Assistant
Supports login, profile display, and health queries via /chat endpoint
"""

import streamlit as st
import requests
import json
import os
import re
from typing import Optional, Dict, Any
import pandas as pd
import google.generativeai as genai


API_BASE = os.environ.get("HEALTH_ASSIST_API", "http://127.0.0.1:8000")

# Configure Gemini for AI advice
try:
    api_key = os.environ.get("GOOGLE_API_KEY")
    if api_key:
        genai.configure(api_key=api_key)
        GEMINI_AVAILABLE = True
    else:
        GEMINI_AVAILABLE = False
except Exception:
    GEMINI_AVAILABLE = False


def get_ai_health_advice(message: str, patient_profile: Dict[str, Any]) -> Optional[str]:
    """Get health advice from Gemini AI"""
    if not GEMINI_AVAILABLE:
        return None
    
    try:
        model = genai.GenerativeModel('gemini-pro')
        prompt = f"""
You are a helpful health advisor for a Pakistani health assistance system. 
Provide brief, practical health advice based on the following:

Patient: {patient_profile.get('name')}
City: {patient_profile.get('city')}
Health Concern: {message}

Provide concise, actionable advice in clear bullet points (5-7 points maximum).
Format: Use bullet points with practical, empathetic advice.
Be culturally sensitive and practical for Pakistan context.
"""
        response = model.generate_content(prompt)
        return response.text if response else None
    except Exception as e:
        st.warning(f"Could not fetch AI advice: {str(e)}")
        return None


def mask_cnic(cnic: str) -> str:
    """Mask CNIC for security: shows first 4 and last 2 digits with ****"""
    if not cnic or len(cnic) < 6:
        return "****"
    # Remove hyphens if present
    clean_cnic = cnic.replace("-", "").strip()
    if len(clean_cnic) < 6:
        return "****"
    first_4 = clean_cnic[:4]
    last_2 = clean_cnic[-2:]
    return f"{first_4}****{last_2}"


def load_local_profile(cnic: str) -> Optional[Dict[str, Any]]:
    """Load citizen profile from data/citizens.json"""
    path = os.path.join("data", "citizens.json")
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            for p in data:
                if p.get("cnic") == cnic:
                    return p
        elif isinstance(data, dict):
            return data.get(cnic) or data
    except Exception:
        return None
    return None


def fetch_profile(cnic: str) -> Optional[Dict[str, Any]]:
    """Try API /profile/{cnic} then fallback to local citizens.json"""
    try:
        url = f"{API_BASE}/profile/{cnic}"
        resp = requests.get(url, timeout=5)
        if resp.status_code == 200:
            return resp.json()
    except Exception:
        pass
    return load_local_profile(cnic)


def post_chat_message(message: str, patient_profile: Dict[str, Any]) -> Dict[str, Any]:
    """Post to /chat endpoint with message and patient profile"""
    url = f"{API_BASE}/chat"
    payload = {
        "message": message,
        "patient_profile": patient_profile
    }
    resp = requests.post(url, json=payload, timeout=15)
    resp.raise_for_status()
    return resp.json()


def parse_markdown_table(md: str) -> Optional[pd.DataFrame]:
    """Parse markdown table into DataFrame"""
    try:
        lines = [l.strip() for l in md.splitlines() if l.strip()]
        if len(lines) < 2:
            return None
        header = [c.strip() for c in lines[0].split("|") if c.strip()]
        rows = []
        for l in lines[2:]:
            cols = [c.strip() for c in l.split("|") if c.strip()]
            if cols:
                rows.append(cols)
        if not rows:
            return None
        df = pd.DataFrame(rows, columns=header)
        return df
    except Exception:
        return None


def format_response_section(text: str) -> str:
    """Clean up and format response text by removing extra formatting characters"""
    if not text:
        return ""
    # Remove emoji and icon markers that appear at start of lines
    lines = []
    for line in text.split("\n"):
        # Clean up lines with emoji/icon markers
        line = line.strip()
        if line:
            # Remove leading icons/emoji
            line = re.sub(r"^[🏥💳⏰🔍📋]+\s*", "", line)
            if line:
                lines.append(line)
    return "\n".join(lines)


def render_response(resp: Dict[str, Any]):
    """Render the /chat response in a nicely formatted way"""
    st.markdown("---")
    
    # Get formatted response (English and Urdu)
    fr = resp.get("formatted_response") or {}
    english = fr.get("english") or ""
    urdu = fr.get("urdu") or ""
    
    # Clean up the response text
    english_clean = format_response_section(english)
    
    # Display in columns
    col1, col2 = st.columns([2, 1])
    with col1:
        st.markdown("### 📋 Response")
        st.markdown(english_clean)
    
    with col2:
        if urdu:
            st.markdown("### اردو خلاصہ")
            urdu_clean = format_response_section(urdu)
            # Black text on light background for better visibility
            st.markdown(f"<div style='background:#f0f2f6;padding:12px;border-radius:8px;font-size:13px;color:#000000;line-height:1.6'>{urdu_clean}</div>", unsafe_allow_html=True)
    
    # Parse json_trace for additional details
    trace = resp.get("json_trace") or {}
    
    if isinstance(trace, dict):
        # Show facility info if present
        facility = trace.get("facility")
        if facility and isinstance(facility, dict):
            st.markdown("---")
            st.markdown("### 🏥 Recommended Facility")
            name = facility.get("name", "N/A")
            location = facility.get("location", "")
            city = facility.get("city", "")
            phone = facility.get("phone", "")
            services = facility.get("services", [])
            
            facility_col1, facility_col2 = st.columns(2)
            with facility_col1:
                st.markdown(f"**📍 {name}**")
                if location:
                    st.markdown(f"**Address:** {location}")
                if city:
                    st.markdown(f"**City:** {city}")
            with facility_col2:
                if phone:
                    st.markdown(f"**📞 Contact:** {phone}")
                if services:
                    st.markdown(f"**Services:**")
                    for svc in services:
                        st.markdown(f"- {svc}")
    
    # Show degraded mode warning if applicable
    if resp.get("degraded_mode"):
        st.warning("⚠️ System is running in degraded mode. Some features may be limited.")


def render_profile_dashboard(profile: Dict[str, Any]):
    """Render user profile in dashboard format"""
    st.subheader("👤 Profile Dashboard")
    
    # Get credits once (single source of truth)
    credits = profile.get("sehat_card_credits") or profile.get("remaining_credits") or 0
    
    # Main profile info in 4 columns
    cols = st.columns(4)
    with cols[0]:
        st.metric("Name", profile.get("name", "—"))
    with cols[1]:
        # Display masked CNIC for security
        masked_cnic = mask_cnic(profile.get("cnic", ""))
        st.metric("CNIC", masked_cnic)
    with cols[2]:
        income = profile.get("income_group") or profile.get("income") or "—"
        st.metric("Income Group", str(income))
    with cols[3]:
        # Show credits in header
        st.metric("Sehat Card Credits", f"PKR {credits:,.0f}" if credits else "—")
    
    st.markdown("---")
    
    # Eligibility and health info
    col_a, col_b = st.columns(2)
    with col_a:
        elig = profile.get("eligibility") or {}
        if isinstance(elig, dict):
            eligible = elig.get("eligible", "Unknown")
            st.metric("Eligibility Status", "✅ Eligible" if eligible else "❌ Not Eligible")
        else:
            st.metric("Eligibility Status", str(elig))
    
    with col_b:
        # Past conditions
        conditions = profile.get("past_conditions") or profile.get("past_diseases") or profile.get("health_conditions") or []
        if conditions:
            with st.expander(f"📋 Health History ({len(conditions)} items)"):
                for cond in conditions:
                    st.markdown(f"- {cond}")
        else:
            st.info("No past medical conditions recorded")
    
    # Show city
    city = profile.get("city", "Unknown")
    st.metric("📍 City", city)


def main():
    st.set_page_config(
        page_title="Sehat Card Assistance",
        layout="wide",
        initial_sidebar_state="collapsed"
    )
    
    # Custom styling
    st.markdown("""
        <style>
        .main { padding: 0rem 1rem; }
        h1 { color: #0066cc; }
        h2, h3 { color: #004499; }
        </style>
    """, unsafe_allow_html=True)
    
    st.markdown("# 🏥 Sehat Card Health Assistant")
    st.markdown("Get health advice, check eligibility, and find nearby facilities")
    
    # Initialize session state
    if "cnic" not in st.session_state:
        st.session_state.cnic = ""
    if "profile" not in st.session_state:
        st.session_state.profile = None
    
    # Layout: Left sidebar for login, main area for profile & chat
    with st.sidebar:
        st.header("🔐 Login")
        
        # Load test CNICs from citizens.json
        test_cnic_list = []
        citizens_path = os.path.join("data", "citizens.json")
        test_profiles = {}
        
        if os.path.exists(citizens_path):
            try:
                with open(citizens_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, list):
                    for p in data:
                        if p.get("cnic"):
                            test_cnic_list.append(f"{p.get('name')} ({p.get('city')})")
                            test_profiles[test_cnic_list[-1]] = p.get("cnic")
            except Exception:
                pass
        
        # CNIC input or dropdown
        st.markdown("**Enter your CNIC or select from list:**")
        
        if test_cnic_list:
            selected = st.selectbox(
                "Quick login with test citizen",
                [""] + test_cnic_list,
                key="quick_login"
            )
            if selected:
                st.session_state.cnic = test_profiles[selected]
        
        cnic_manual = st.text_input(
            "Or enter CNIC manually",
            value=st.session_state.cnic,
            key="cnic_input",
            placeholder="34501-1234567-1"
        )
        
        if cnic_manual and cnic_manual != st.session_state.cnic:
            st.session_state.cnic = cnic_manual
        
        st.markdown("---")
        
        if st.button("🔓 Login", key="login_btn", use_container_width=True):
            if not st.session_state.cnic:
                st.error("Please enter a CNIC to login")
            else:
                with st.spinner("Loading profile..."):
                    profile = fetch_profile(st.session_state.cnic)
                    if profile is None:
                        st.warning("Profile not found. Creating basic profile from CNIC.")
                        profile = {
                            "cnic": st.session_state.cnic,
                            "name": "Test User",
                            "city": "Lahore",
                            "income_group": "low",
                            "eligibility": {"eligible": True},
                            "sehat_card_credits": 100000,
                            "health_conditions": []
                        }
                    st.session_state.profile = profile
                    st.success(f"✅ Logged in as {profile.get('name')}")
        
        if st.session_state.profile:
            st.markdown("---")
            if st.button("🚪 Logout", key="logout_btn", use_container_width=True):
                st.session_state.profile = None
                st.session_state.cnic = ""
                st.rerun()
    
    # Main content area
    if st.session_state.profile:
        p = st.session_state.profile
        
        # Profile Dashboard
        render_profile_dashboard(p)
        
        st.markdown("---")
        st.markdown("## 💬 Ask a Question / Get Health Advice")
        
        # Message input
        message = st.text_area(
            "What health concern would you like help with?",
            height=100,
            placeholder="e.g., 'I have a headache for 2 days', 'My wife is pregnant, where can we get checkup'",
            key="message_input"
        )
        
        # Additional options
        col_opt1, col_opt2, col_btn = st.columns([2, 2, 1])
        with col_opt1:
            show_urdu = st.checkbox("Show Urdu translation", value=True)
        with col_opt2:
            pass
        with col_btn:
            submit_btn = st.button("📤 Submit", key="submit_btn", use_container_width=True)
        
        # Process submission
        if submit_btn:
            if not message.strip():
                st.error("Please enter a message")
            else:
                with st.spinner("🔄 Processing your request..."):
                    try:
                        # Build patient profile for /chat endpoint
                        patient_profile = {
                            "cnic": p.get("cnic"),
                            "name": p.get("name"),
                            "city": p.get("city")
                        }
                        
                        # First, fetch AI advice if available
                        ai_advice = None
                        if GEMINI_AVAILABLE:
                            with st.spinner("🤖 Getting AI health advice..."):
                                ai_advice = get_ai_health_advice(message, patient_profile)
                        
                        # Then post to /chat endpoint
                        response = post_chat_message(message, patient_profile)
                        
                        # Display AI Advice FIRST (if available)
                        if ai_advice:
                            st.markdown("---")
                            with st.container():
                                st.markdown("### 🤖 AI Health Advice (from Gemini)")
                                st.markdown(ai_advice)
                            st.markdown("---")
                        
                        # Then render the backend response (recommendations, facilities, etc.)
                        st.markdown("### 💼 System Recommendations")
                        render_response(response)
                        
                        # Optional: show journey trace for debugging
                        with st.expander("📊 View Full Response Trace"):
                            st.json(response.get("json_trace", {}))
                    
                    except requests.exceptions.ConnectionError:
                        st.error(
                            f"❌ **Backend Connection Error**\n\n"
                            f"The backend server is not running at {API_BASE}.\n\n"
                            f"**To fix this, open a PowerShell terminal and run:**\n\n"
                            f"`& ./.venv/Scripts/python.exe -m uvicorn app:app --host 127.0.0.1 --port 8000`\n\n"
                            f"Then refresh this page."
                        )
                    except requests.exceptions.Timeout:
                        st.error("⏱️ Request timed out. Please try again.")
                    except requests.HTTPError as e:
                        error_detail = "Unknown error"
                        try:
                            error_detail = e.response.text
                        except Exception:
                            error_detail = f"HTTP {e.response.status_code}"
                        st.error(f"❌ Server error: {error_detail}")
                    except Exception as e:
                        st.error(f"❌ Error: {str(e)}")
    
    else:
        # Show login prompt
        st.info(
            "👈 **Please login with your CNIC** using the sidebar to access health advice and facility recommendations.\n\n"
            "Don't have a CNIC? Use one of the test CNICs from the quick login dropdown."
        )
        
        # Show available test users
        if os.path.exists(citizens_path):
            try:
                with open(citizens_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, list):
                    st.subheader("👥 Available Test Users")
                    test_df = pd.DataFrame([
                        {
                            "Name": p.get("name"),
                            "City": p.get("city"),
                            "CNIC": p.get("cnic"),
                            "Status": "Enrolled" if p.get("enrolled") else "Not Enrolled"
                        }
                        for p in data[:5]
                    ])
                    st.table(test_df)
            except Exception:
                pass


if __name__ == "__main__":
    main()
