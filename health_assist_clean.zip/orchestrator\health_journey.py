"""
Health Journey Orchestrator that coordinates the flow between different agents
to provide a complete healthcare assistance experience.
"""

import os
import json
import logging
from datetime import datetime
from typing import Dict, Any, Optional

from agents.triage_agent import TriageAgent
from agents.program_eligibility_agent import ProgramEligibilityAgent 
from agents.facility_finder_agent import FacilityFinderAgent
from agents.followup_agent import FollowupAgent

class HealthJourneyOrchestrator:
    def __init__(self):
        # Setup logging
        self.base_dir = os.path.dirname(os.path.dirname(__file__))
        self.log_dir = os.path.join(self.base_dir, 'logs')
        os.makedirs(self.log_dir, exist_ok=True)
        
        self.logger = logging.getLogger('health_journey_orchestrator')
        self.logger.setLevel(logging.INFO)
        
        handler = logging.FileHandler(os.path.join(self.log_dir, 'orchestrator.log'))
        handler.setFormatter(logging.Formatter(
            '%(asctime)s %(levelname)s %(message)s'
        ))
        self.logger.addHandler(handler)
        
        # Initialize agents
        self.triage_agent = TriageAgent()
        self.eligibility_agent = ProgramEligibilityAgent()
        self.facility_agent = FacilityFinderAgent()
        self.followup_agent = FollowupAgent()
        
        self.logger.info("HealthJourneyOrchestrator initialized with all agents")

    def _add_source_and_timestamp(self, result: Dict[str, Any], agent_name: str) -> Dict[str, Any]:
        """Add source agent and timestamp to agent results."""
        if isinstance(result, dict):
            result.update({
                "source_agent": agent_name,
                "timestamp": datetime.now().isoformat()
            })
        return result

    def run_health_journey(self, user_input: Dict[str, Any], 
                          patient_profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Run the complete health assistance journey through all agents.
        
        Args:
            user_input: Dictionary containing:
                - symptoms: String describing the symptoms
                - language: Preferred language (optional)
            patient_profile: Dictionary containing:
                - cnic: Patient's CNIC number
                - name: Patient's name
                - location: Patient's location
                - other profile fields...
                
        Returns:
            Dictionary containing results from all agents with trace information
        """
        journey_trace = {
            "journey_id": f"journey_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "patient_cnic": patient_profile.get('cnic'),
            "start_time": datetime.now().isoformat(),
            "completion_status": "pending",
            "degraded_mode": False
        }
        
        try:
            self.logger.info(f"Starting health journey for CNIC: {patient_profile.get('cnic')}")
            
            # Step 1: Triage Assessment
            self.logger.info("Step 1: Running triage assessment")
            triage_request = {
                "symptoms": user_input.get('symptoms', ''),
                "cnic": patient_profile.get('cnic')
            }
            triage_result = self.triage_agent.assess_symptoms(triage_request)
            journey_trace["triage"] = self._add_source_and_timestamp(triage_result, "triage_agent")
            
            if triage_result.get("status") == "error":
                journey_trace["completion_status"] = "failed_at_triage"
                self.logger.error(f"Triage failed: {triage_result.get('message')}")
                return journey_trace
            
            # Check if self-care is recommended
            severity = triage_result.get('severity', '').lower()
            if severity == 'self-care':
                journey_trace["completion_status"] = "completed_self_care"
                self.logger.info("Self-care recommended, skipping facility search")
                return journey_trace
            
            # Step 2: Eligibility Check
            self.logger.info("Step 2: Checking program eligibility")
            eligibility_result = self.eligibility_agent.evaluate_eligibility(
                patient_profile.get('cnic')
            )
            journey_trace["eligibility"] = self._add_source_and_timestamp(
                eligibility_result, 
                "eligibility_agent"
            )
            
            if eligibility_result.get("status") == "error":
                self.logger.warning(f"Eligibility check failed: {eligibility_result.get('message')}")
            
            # Step 3: Facility Finding
            self.logger.info("Step 3: Finding appropriate facilities")
            facility_result = self.facility_agent.recommend_facility(
                patient_profile.get('cnic'),
                severity
            )
            journey_trace["facilities"] = self._add_source_and_timestamp(
                facility_result,
                "facility_agent"
            )
            
            # Step 4: Create Follow-up Reminders
            self.logger.info("Step 4: Creating follow-up reminders")
            reminder_result = self.followup_agent.create_reminders(
                patient_profile.get('cnic'),
                triage_result,
                facility_result if facility_result.get("status") == "success" else None
            )
            journey_trace["reminders"] = self._add_source_and_timestamp(
                reminder_result,
                "followup_agent"
            )
            
            # Check for degraded mode in any agent
            journey_trace["degraded_mode"] = any([
                triage_result.get("source") == "degraded",
                eligibility_result.get("source") == "degraded",
                facility_result.get("source") == "degraded",
                reminder_result.get("source") == "degraded"
            ])
            
            journey_trace["completion_status"] = "completed"
            journey_trace["end_time"] = datetime.now().isoformat()
            
            self.logger.info(f"Health journey completed for CNIC: {patient_profile.get('cnic')}")
            return journey_trace
            
        except Exception as e:
            error_msg = f"Error in health journey: {str(e)}"
            self.logger.error(error_msg, exc_info=True)
            
            journey_trace.update({
                "completion_status": "failed",
                "error": error_msg,
                "end_time": datetime.now().isoformat()
            })
            return journey_trace