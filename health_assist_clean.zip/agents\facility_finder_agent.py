"""
Facility Finder Agent that recommends healthcare facilities based on patient needs.
Integrates with facility finding helper functions and provides user-friendly responses.
"""

import logging
import os
from typing import Dict, Any
from helpers.sehat_helpers import find_nearest_facility
from helpers.data_utils import get_citizen_by_cnic
from helpers.retriever import Retriever
from agents.session_context import SessionContext
from helpers.condition_service_map import CONDITION_SERVICE_MAP
from helpers.response_formatter import ResponseFormatter

class FacilityFinderAgent:
    def __init__(self):
        # Setup logging
        log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
        os.makedirs(log_dir, exist_ok=True)
        
        self.logger = logging.getLogger('facility_finder_agent')
        self.logger.setLevel(logging.INFO)
        
        handler = logging.FileHandler(os.path.join(log_dir, 'facility_finder_agent.log'))
        handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
        self.logger.addHandler(handler)

        # Retriever for local RAG-style lookups
        self.retriever = Retriever()

    def recommend_facility(self, session_or_cnic, urgency: str) -> Dict[str, Any]:
        """
        Recommend appropriate healthcare facilities based on patient location and urgency.
        
        Args:
            cnic: Patient's CNIC number
            urgency: Level of medical urgency ("emergency", "hospital", "bhu", "routine")
            
        Returns:
            Dictionary with facility recommendation and formatted message
        """
        try:
            # Accept SessionContext or CNIC string
            if isinstance(session_or_cnic, SessionContext):
                session = session_or_cnic
                cnic = session.cnic
                # ensure profile is loaded
                if session.profile is None:
                    session.load_profile(self.retriever)
                citizen = session.profile
            else:
                cnic = str(session_or_cnic)
                citizen = self.retriever.get_citizen(cnic)
                if not citizen:
                    citizen = get_citizen_by_cnic(cnic)

            self.logger.info(f"Finding facility for CNIC: {cnic}, Urgency: {urgency}")

            if not citizen:
                msg = f"No citizen record found for identifier {cnic}"
                self.logger.warning(msg)
                return {
                    "status": "error",
                    "message": msg
                }

            # Determine search parameters using user profile
            city = (citizen.get('city') or citizen.get('location') or '').strip()
            health_needs = citizen.get('health_conditions', []) or []

            # Map urgency to priority services
            required_services = []
            if urgency and urgency.lower() == 'emergency':
                required_services = ['emergency', 'trauma', '24/7']
            elif urgency and urgency.lower() in ('hospital', 'inpatient'):
                required_services = ['inpatient', 'surgery', 'icu']
            elif urgency and urgency.lower() in ('bhu', 'rhc'):
                required_services = ['outpatient', 'basic_care']
            else:
                # map conditions to services via CONDITION_SERVICE_MAP
                for cond in health_needs:
                    svc = CONDITION_SERVICE_MAP.get(cond.lower())
                    if svc:
                        required_services.append(svc)

            # Use retriever to find matching facilities (it will handle fallback automatically)
            facilities = self.retriever.find_facilities(city, required_services)

            # If retriever found nothing, try legacy helper as last resort
            if not facilities:
                self.logger.info('Retriever returned no facilities, falling back to nearest helper')
                facility_result = find_nearest_facility(cnic, urgency)
                if facility_result.get('status') == 'error':
                    self.logger.error(f"Facility lookup failed: {facility_result.get('message')}")
                    return facility_result

                    # format and return helper result
                    name = citizen.get('name', 'Patient')
                    masked_cnic = f"{cnic[:5]}****{cnic[-4:]}" if len(cnic) >= 13 else "****"
                    facility = facility_result
                    distance_text = facility.get('distance', 'unknown distance')
                    message = (
                        f"For {name} (CNIC {masked_cnic}), the recommended facility is:\n"
                        f"- {facility.get('name')}\n"
                        f"- Type: {facility.get('type', 'Healthcare Facility')}\n"
                        f"- Location: {facility.get('location', 'Location information unavailable')}\n"
                        f"- Distance: {distance_text}\n"
                    )
                    if facility.get('services'):
                        message += f"- Available Services: {', '.join(facility.get('services'))}\n"

                    response = {
                        'status': 'success',
                        'message': message,
                        'facility': facility_result,
                        'citizen_name': name,
                        'source': 'fallback'
                    }
                    self.logger.info(f"Facility recommendation completed for {masked_cnic}")
                    return response
            # Choose best facility (first in ranked list)
            best = facilities[0]
            name = citizen.get('name', 'Patient')
            masked = str(citizen.get('cnic') or citizen.get('id') or cnic)
            masked_cnic = (masked[:5] + '****' + masked[-4:]) if len(masked) >= 13 else masked

            message = (
                f"For {name} (CNIC {masked_cnic}), the recommended facility is:\n"
                f"- {best.get('name')}\n"
                f"- Type: {best.get('type', 'Healthcare Facility')}\n"
                f"- Location: {best.get('location', 'Location information unavailable')}\n"
            )
            if best.get('services'):
                message += f"- Available Services: {', '.join(best.get('services'))}\n"
            if best.get('distance'):
                message += f"- Distance: {best.get('distance')}\n"

            # Map urgency to more user-friendly terms
            urgency_level = {
                'emergency': 'Critical',
                'hospital': 'High',
                'bhu': 'Medium',
                'routine': 'Low'
            }.get(urgency.lower(), 'Medium')
            
            recommended_action = f"Go to {best.get('name')} ({', '.join(required_services)})"
            
            response = ResponseFormatter.format_facility_response(
                facilities=[best] + facilities[1:3],  # Include top 3 matches
                urgency=urgency_level,
                recommended_action=recommended_action,
                raw_response={
                    'source': 'retriever',
                    'search_criteria': {
                        'city': city,
                        'required_services': required_services
                    },
                    'total_matches': len(facilities)
                },
                language="en"
            )
            response['citizen_name'] = name

            self.logger.info(f"Facility recommendation completed for {masked_cnic}")
            return response

        except Exception as e:
            error_msg = f"Error finding facility: {str(e)}"
            self.logger.error(error_msg)
            return {
                "status": "error",
                "message": error_msg
            }