"""Shared response formatting utilities for consistent agent outputs."""

import json
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone

def format_currency(amount: float) -> str:
    """Format amount as PKR with commas."""
    return f"PKR {amount:,.0f}"

def format_markdown_table(headers: List[str], rows: List[List[str]]) -> str:
    """Create a markdown table from headers and rows."""
    # Header row
    table = "| " + " | ".join(headers) + " |\n"
    # Separator row
    table += "| " + " | ".join(["---" for _ in headers]) + " |\n"
    # Data rows
    for row in rows:
        table += "| " + " | ".join(str(cell) for cell in row) + " |\n"
    return table

class ResponseFormatter:
    @staticmethod
    def format_eligibility_response(
        eligible: bool,
        remaining_credits: float,
        income_group: str,
        raw_response: Optional[Dict[str, Any]] = None,
        language: str = "en"
    ) -> Dict[str, Any]:
        """Format program eligibility response."""
        # Keep top-level status compatible with existing tests/UI expectations
        status = "success"
        eligibility_label = "Eligible" if eligible else "Not Eligible"

        # Create summary table data
        headers = ["Category", "Details"]
        rows = [
            ["Status", eligibility_label],
            ["Remaining Credits", format_currency(remaining_credits)],
            ["Income Group", income_group]
        ]

        result = {
            "status": status,
            "eligible": eligible,
            "eligibility_label": eligibility_label,
            "remaining_credits": format_currency(remaining_credits),
            "income_group": income_group,
            "language": language,
            "raw_response": raw_response,
            "raw_answer": raw_response,  # alias expected by UI
            "summary_table": format_markdown_table(headers, rows),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

        # If raw_response carries a source, surface it at top-level for tests/UI
        if isinstance(raw_response, dict) and raw_response.get('source'):
            result['source'] = raw_response.get('source')

        return result

    @staticmethod
    def format_facility_response(
        facilities: List[Dict[str, Any]],
        urgency: str,
        recommended_action: str,
        raw_response: Optional[Dict[str, Any]] = None,
        language: str = "en"
    ) -> Dict[str, Any]:
        """Format facility finder response."""
        # Create summary table with facility details
        if facilities:
            headers = ["Facility", "City", "Services", "Contact"]
            rows = []
            for f in facilities:
                services = ", ".join(f.get("services", []))
                if len(services) > 50:  # Truncate long service lists
                    services = services[:47] + "..."
                rows.append([
                    f.get("name", "Unknown"),
                    f.get("city", "Unknown"),
                    services,
                    f.get("phone", "N/A")
                ])
            
            status = "success"
        else:
            headers = ["Message"]
            rows = [["No facilities found matching criteria"]]
            status = "not_found"
            
        # Compose a human-friendly message and provide backward-compatible keys
        message = "No facilities found matching criteria" if not facilities else f"Found {len(facilities)} facility(ies); top recommendation: {facilities[0].get('name', 'Unknown')} in {facilities[0].get('city', 'Unknown')}"

        result = {
            "status": "success" if status == "success" else "not_found",
            "urgency": urgency,
            "recommended_action": recommended_action,
            "facilities": facilities,
            "facility": facilities[0] if facilities else None,  # backward-compatible single facility
            "message": message,
            "language": language,
            "raw_response": raw_response,
            "raw_answer": raw_response,
            "summary_table": format_markdown_table(headers, rows),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

        # If raw_response carries a source, surface it at top-level for tests/UI
        if isinstance(raw_response, dict) and raw_response.get('source'):
            result['source'] = raw_response.get('source')

        return result

    @staticmethod 
    def format_triage_response(
        severity: str,
        reasons: List[str],
        recommendation: str,
        raw_response: Optional[Dict[str, Any]] = None,
        language: str = "en",
        severity_level: int = 1
    ) -> Dict[str, Any]:
        """Format triage assessment response."""
        urgency_map = {
            1: "Low",
            2: "Medium", 
            3: "High",
            4: "Critical"
        }
        
        headers = ["Category", "Details"]
        rows = [
            ["Severity", severity],
            ["Urgency", urgency_map.get(severity_level, "Unknown")],
            ["Key Reasons", "\n".join(f"- {r}" for r in reasons)]
        ]
        result = {
            "status": "success",
            "severity": severity,
            "urgency": urgency_map.get(severity_level, "Unknown"),
            "reasons": reasons,
            "recommendation": recommendation,
            "severity_level": severity_level,
            "language": language,
            "raw_response": raw_response,
            "raw_answer": raw_response,
            "summary_table": format_markdown_table(headers, rows),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }

        if isinstance(raw_response, dict) and raw_response.get('source'):
            result['source'] = raw_response.get('source')

        # Surface urdu_summary from gemini output (if present) at top-level for UI/tests
        if isinstance(raw_response, dict):
            # direct urdu_summary
            if raw_response.get('urdu_summary'):
                result['urdu_summary'] = raw_response.get('urdu_summary')
            # gemini_output nested payload
            elif isinstance(raw_response.get('gemini_output'), dict) and raw_response['gemini_output'].get('urdu_summary'):
                result['urdu_summary'] = raw_response['gemini_output'].get('urdu_summary')
            # handle deeper nesting where agents embed 'gemini_output' under 'gemini_output'
            elif isinstance(raw_response.get('gemini_output'), dict) and isinstance(raw_response['gemini_output'].get('gemini_output'), dict) and raw_response['gemini_output']['gemini_output'].get('urdu_summary'):
                result['urdu_summary'] = raw_response['gemini_output']['gemini_output'].get('urdu_summary')

        return result