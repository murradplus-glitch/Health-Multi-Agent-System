#!/usr/bin/env python3
"""
Eligibility agent that calls MCP program_eligibility_tool and uses Gemini
to produce a simple Urdu+English explanation. Falls back to raw tool output
if Gemini fails.
"""
import os
import json
import logging
from typing import Dict, Any, Optional, List
import requests
import google.generativeai as genai

# Logging
LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
os.makedirs(LOG_DIR, exist_ok=True)
logging.basicConfig(
    filename=os.path.join(LOG_DIR, 'eligibility_agent.log'),
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)

# Gemini config: read API key from environment for safety
GEMINI_API_KEY = os.environ.get('GOOGLE_API_KEY')

MCP_BASE_URL = "http://127.0.0.1:5000"


def call_program_eligibility(profile: Dict[str, Any]) -> Dict[str, Any]:
    url = f"{MCP_BASE_URL}/program_eligibility_tool"
    try:
        r = requests.post(url, json=profile, timeout=5)
        r.raise_for_status()
        res = r.json()
        logging.info(f"program_eligibility_tool result: {json.dumps(res)}")
        return res
    except Exception as e:
        logging.warning(f"HTTP call to program_eligibility_tool failed: {e}; trying Flask test_client fallback")
        try:
            from mcp_server import app as mcp_app
            with mcp_app.test_client() as client:
                r = client.post('/program_eligibility_tool', json=profile)
                return r.get_json() or {"eligible_programs": []}
        except Exception as ex:
            logging.exception('Flask test_client fallback also failed: %s', ex)
            return {"eligible_programs": []}


def explain_with_gemini(profile: Dict[str, Any], triage_result: Dict[str, Any], programs: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Ask Gemini to generate a comprehensive eligibility explanation.

    Returns a dict with structured explanations or None on failure.
    """
    prompt = (
        "You are a healthcare financial assistance advisor in Pakistan.\n\n"
        "Context:\n"
        "- You help patients understand their eligibility for healthcare programs\n"
        "- You need to explain complex criteria in simple terms\n"
        "- Your audience may have limited healthcare and financial literacy\n\n"
        "Instructions:\n"
        "1. Analyze the user's profile and triage result\n"
        "2. Review eligible programs and their requirements\n"
        "3. Create clear explanations in both English and Roman Urdu\n"
        "4. Provide practical next steps\n\n"
        "Generate a JSON response with:\n"
        "- summary_en: Clear English explanation of eligibility\n"
        "- summary_urdu: Roman Urdu explanation (simple terms)\n"
        "- eligible_count: Number of programs they qualify for\n"
        "- action_items: List of specific steps to take\n"
        "- emergency_note: Special instructions if triage severity is high\n\n"
        f"Profile: {json.dumps(profile)}\n"
        f"Triage: {json.dumps(triage_result)}\n"
        f"Programs: {json.dumps(programs)}"
    )

    # If no API key is available, skip calling Gemini
    if not GEMINI_API_KEY:
        logging.info('No GOOGLE_API_KEY set; skipping Gemini and returning None')
        return None

    try:
        # Initialize the client
        client = genai.Client(api_key=GEMINI_API_KEY)
        
        # Call Gemini model
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt
        )
        
        text = response.text
        logging.info(f"Gemini eligibility explanation: {text}")
        
        # Parse the JSON response
        try:
            # Find JSON in the response
            start = text.find('{')
            end = text.rfind('}')
            if start != -1 and end != -1 and end > start:
                json_str = text[start:end+1]
                parsed = json.loads(json_str)
                
                # Validate required fields
                required_fields = ['summary_en', 'summary_urdu', 'eligible_count', 'action_items', 'emergency_note']
                if all(field in parsed for field in required_fields):
                    return parsed
                
            logging.warning("Gemini response missing required fields")
            return None
        except Exception as e:
            logging.exception("Failed to parse Gemini response as JSON: %s", e)
            return None
    except Exception as e:
        logging.error(f"Gemini eligibility call failed: {e}")
        return None


def check_eligibility(profile: Dict[str, Any], triage_result: Dict[str, Any]) -> Dict[str, Any]:
    """Check and explain program eligibility with enhanced response.

    Steps:
    1. Call MCP program_eligibility_tool with profile
    2. Generate comprehensive explanation using Gemini
    3. Return structured response with programs and explanations
    4. Fall back to simpler format if Gemini fails
    """
    logging.info(f"Checking eligibility for profile: {json.dumps(profile)} with triage: {json.dumps(triage_result)}")
    
    # Get eligible programs from MCP tool
    tool_result = call_program_eligibility(profile)
    programs = tool_result.get('eligible_programs', [])

    # Try to get enhanced explanation from Gemini
    gemini_response = explain_with_gemini(profile, triage_result, programs)

    if gemini_response is None:
        # Degraded mode - return basic structure
        logging.info("Gemini failed; returning simplified response")
        basic_explanation = {
            "summary_en": "Based on your profile, you may be eligible for some programs.",
            "summary_urdu": "Ap kuch health programs ke liye eligible ho sakte hain.",
            "eligible_count": len(programs),
            "action_items": ["Visit your nearest healthcare center for enrollment"],
            "emergency_note": "" if triage_result.get("severity") not in ["emergency", "hospital"] else "Please seek medical care first before program enrollment."
        }
        return {
            "eligible_programs": programs,
            "explanations": basic_explanation,
            "source": "degraded"
        }

    # Full response with Gemini-enhanced explanations
    return {
        "eligible_programs": programs,
        "explanations": gemini_response,
        "source": "gemini"
    }


if __name__ == '__main__':
    # quick manual test
    profile = {"poverty_score": 25, "enrolled": False}
    triage = {"severity": "self-care", "reasons": [], "advice": "Rest"}
    res = check_eligibility(profile, triage)
    print(json.dumps(res, indent=2, ensure_ascii=False))
