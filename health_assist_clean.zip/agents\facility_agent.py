"""
Facility Agent for finding and ranking appropriate healthcare facilities.
Uses Gemini API for natural language explanations and facility ranking.
"""
import os
import json
import logging
from typing import Dict, Any, List
import google.generativeai as genai
from mcp.client import MCPClient

# Setup logging
LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
os.makedirs(LOG_DIR, exist_ok=True)

logging.basicConfig(
    filename=os.path.join(LOG_DIR, 'facility_agent.log'),
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s'
)

# Initialize Gemini
try:
    genai.configure(api_key=os.getenv('GOOGLE_API_KEY'))
    model = genai.GenerativeModel('gemini-pro')
    GEMINI_ENABLED = True
except Exception as e:
    logging.error(f"Failed to initialize Gemini: {e}")
    GEMINI_ENABLED = False

def rank_and_explain_facilities(facilities: List[Dict[str, Any]], triage_result: Dict[str, Any]) -> Dict[str, Any]:
    """Use Gemini to rank facilities and explain recommendations."""
    if not GEMINI_ENABLED or not facilities:
        return None

    try:
        prompt = f"""
        As a healthcare facility expert in Pakistan, analyze these facilities and triage results:

        Triage Result:
        {json.dumps(triage_result, indent=2)}

        Available Facilities:
        {json.dumps(facilities, indent=2)}

        Please:
        1. Pick the top 3 most appropriate facilities based on:
           - Urgency level from triage
           - Facility capabilities
           - Location and accessibility
           - Current availability
           
        2. Explain why each facility was chosen
        
        Return the response in this JSON format:
        {{
            "top_facilities": [
                {{
                    "facility_id": "id",
                    "name": "name",
                    "rank": 1-3,
                    "reason": "explanation for this choice"
                }}
            ],
            "summary_en": "Overall recommendation in English",
            "summary_urdu": "Overall recommendation in Urdu script"
        }}
        """

        response = model.generate_content(prompt)
        return json.loads(response.text)
    except Exception as e:
        logging.error(f"Gemini ranking failed: {e}")
        return None

def find_facilities(location: str, triage_result: Dict[str, Any]) -> Dict[str, Any]:
    """
    Find and rank appropriate healthcare facilities based on location and triage results.
    
    Args:
        location: Patient's location
        triage_result: Results from triage assessment
        
    Returns:
        Dictionary containing ranked facilities and explanations
    """
    try:
        logging.info(f"Finding facilities for location: {location}")
        
        # Initialize MCP client
        mcp = MCPClient()
        
        # Prepare facility lookup request
        lookup_request = {
            "location": location,
            "triage": triage_result
        }
        
        # Call MCP facility lookup tool
        facilities = mcp.call_tool(
            "facility_lookup_tool",
            lookup_request
        )
        
        if not facilities:
            error_msg = "Failed to get facilities from MCP tool"
            logging.error(error_msg)
            return {
                "status": "error",
                "message": error_msg
            }

        # Get Gemini analysis if available
        gemini_result = rank_and_explain_facilities(facilities, triage_result)
        
        if gemini_result:
            response = {
                "status": "success",
                "ranked_facilities": gemini_result["top_facilities"][:3],
                "all_facilities": facilities,
                "summary": {
                    "english": gemini_result["summary_en"],
                    "urdu": gemini_result["summary_urdu"]
                },
                "degraded_mode": False
            }
        else:
            # Fallback to basic ranking (e.g., by distance)
            basic_facilities = sorted(
                facilities,
                key=lambda x: x.get('distance', float('inf'))
            )[:3]
            
            response = {
                "status": "success",
                "ranked_facilities": [
                    {
                        "facility_id": f["facility_id"],
                        "name": f["name"],
                        "rank": idx + 1,
                        "reason": "Based on proximity to patient location"
                    }
                    for idx, f in enumerate(basic_facilities)
                ],
                "all_facilities": facilities,
                "summary": {
                    "english": "Facilities ranked by distance to your location",
                    "urdu": "Ye haspatal ap ke maqam se qarib tareen hain"
                },
                "degraded_mode": True
            }

        logging.info(f"Found {len(facilities)} facilities, returning top {len(response['ranked_facilities'])}")
        return response

    except Exception as e:
        error_msg = f"Error finding facilities: {str(e)}"
        logging.error(error_msg)
        return {
            "status": "error",
            "message": error_msg,
            "degraded_mode": True
        }