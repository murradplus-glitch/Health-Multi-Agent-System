"""Router package initialization."""

from .mock_responses import router as mock_router, config as mock_config