"""
FastAPI server for the Health Assistant UI.
Provides REST endpoints and serves HTML interface.
"""

import os
import json
from typing import Dict, Any
from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from contextlib import asynccontextmanager

from orchestrator.health_journey import HealthJourneyOrchestrator
from routers.mock_responses import router as mock_router, config as mock_config

# Initialize orchestrator (create before app so lifespan can consult it)
orchestrator = HealthJourneyOrchestrator()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan handler to replace deprecated startup/shutdown events.

    Sets app.state.gemini_enabled and logs gemini availability. This mirrors
    the previous @app.on_event("startup") behavior but uses the supported
    lifespan API.
    """
    # startup
    gemini_available = False
    try:
        gemini_available = bool(getattr(orchestrator, 'triage_agent', None) and getattr(orchestrator.triage_agent, 'gemini_enabled', False))
    except Exception:
        gemini_available = False

    app.state.gemini_enabled = gemini_available
    import logging
    logger = logging.getLogger('uvicorn')
    if gemini_available:
        logger.info('Gemini client available — Gemini-enabled features ON')
    else:
        logger.info('Gemini client NOT available — using MCP/local fallbacks')

    try:
        yield
    finally:
        # shutdown (no-op for now)
        pass

# Initialize FastAPI app with lifespan
app = FastAPI(title="Health Assistant", lifespan=lifespan)

# Setup templates and static files
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")

class ChatRequest(BaseModel):
    message: str
    patient_profile: Dict[str, Any]

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """Serve the main chat interface."""
    return templates.TemplateResponse(
        "chat.html",
        {"request": request}
    )

def get_router():
    """Get appropriate router based on mock mode configuration."""
    return mock_router if mock_config.enabled else app

# Register mock router
app.include_router(mock_router, prefix="", include_in_schema=True)

@app.post("/chat")
async def chat(chat_request: ChatRequest, router=Depends(get_router)):
    """
    Process a chat message and return health journey results.
    
    Args:
        chat_request: Contains user message and patient profile
        router: Router dependency for request routing
        
    Returns:
        Formatted response with explanations and JSON trace
    """
    if not mock_config.enabled:
        try:
            # Regular flow - only used when mock mode is disabled
            # (when mock mode is enabled, request is handled by mock router)
            
            # Prepare user input
            user_input = {
                "symptoms": chat_request.message,
                "language": "en"  # Could be made configurable
            }
            
            # Run health journey
            result = orchestrator.run_health_journey(
                user_input=user_input,
                patient_profile=chat_request.patient_profile
            )
            
            # Format response
            response = {
                "status": "success",
                "formatted_response": {
                    "english": format_response_english(result),
                    "urdu": format_response_urdu(result)
                },
                "json_trace": result,
                "degraded_mode": result.get("degraded_mode", False)
            }
            
            return response
            
        except Exception as e:
            raise HTTPException(
                status_code=500,
                detail=f"Error processing request: {str(e)}"
            )
    return await router.routes[0].endpoint(chat_request)
    try:
        # Prepare user input
        user_input = {
            "symptoms": chat_request.message,
            "language": "en"  # Could be made configurable
        }
        
        # Run health journey
        result = orchestrator.run_health_journey(
            user_input=user_input,
            patient_profile=chat_request.patient_profile
        )
        
        # Format response
        response = {
            "status": "success",
            "formatted_response": {
                "english": format_response_english(result),
                "urdu": format_response_urdu(result)
            },
            "json_trace": result,
            "degraded_mode": result.get("degraded_mode", False)
        }
        
        return response
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error processing request: {str(e)}"
        )

def format_response_english(result: Dict[str, Any]) -> str:
    """Format journey results in English."""
    sections = []
    
    # Format triage results
    if "triage" in result:
        triage = result["triage"]
        sections.append(
            "🏥 MEDICAL ASSESSMENT:\n"
            f"Level of Care: {triage.get('severity', 'Unknown').upper()}\n"
            f"Recommendation: {triage.get('recommendation', 'No specific recommendation')}"
        )
    
    # Format eligibility results
    if "eligibility" in result:
        eligibility = result["eligibility"]
        sections.append(
            "💳 PROGRAM ELIGIBILITY:\n"
            f"{eligibility.get('message', 'No eligibility information available')}"
        )
    
    # Format facility results
    if "facilities" in result and result["facilities"].get("status") == "success":
        facility = result["facilities"]
        facility_text = [
            "🏥 RECOMMENDED FACILITIES:",
            f"Primary: {facility.get('name')} ({facility.get('type', 'Unknown')})",
            f"Location: {facility.get('location')} - {facility.get('distance', 'Unknown distance')}"
        ]
        
        if facility.get("alternatives"):
            facility_text.append("\nAlternative Facilities:")
            for alt in facility["alternatives"]:
                facility_text.append(
                    f"- {alt.get('name')} ({alt.get('type', 'Unknown')}) - {alt.get('distance', 'Unknown')}"
                )
        sections.append("\n".join(facility_text))
    
    # Format reminders
    if "reminders" in result and result["reminders"].get("reminders"):
        reminder_text = ["⏰ FOLLOW-UP REMINDERS:"]
        for reminder in result["reminders"]["reminders"]:
            reminder_text.append(
                f"- {reminder.get('type', 'Reminder')}: {reminder.get('message', 'No message')}"
            )
        sections.append("\n".join(reminder_text))
    
    # Add degraded mode warning if applicable
    if result.get("degraded_mode"):
        sections.append(
            "⚠️ Note: Some services are operating in backup mode. "
            "Results may be simplified."
        )
    
    return "\n\n".join(sections)

def format_response_urdu(result: Dict[str, Any]) -> str:
    """Format journey results in Urdu (Roman script)."""
    sections = []
    
    # Format triage results
    if "triage" in result:
        triage = result["triage"]
        severity_urdu = {
            "emergency": "Emergency - Fori Haalat",
            "hospital": "Hospital - Haspatal",
            "BHU": "Basic Health Unit",
            "self-care": "Ghar Par Dekhbhal"
        }
        sections.append(
            "🏥 TIBBI JAIZA:\n"
            f"Zarurat: {severity_urdu.get(triage.get('severity', ''), 'Naamalom')}\n"
            f"Mashwara: {triage.get('urdu_summary', 'Koi khaas mashwara nahi')}"
        )
    
    # Format eligibility results
    if "eligibility" in result:
        eligibility = result["eligibility"]
        if eligibility.get("eligible"):
            sections.append(
                "💳 SEHAT CARD:\n"
                "Ap Sehat Card program ke liye eligible hain"
            )
        else:
            sections.append(
                "💳 SEHAT CARD:\n"
                "Abhi ap Sehat Card program ke liye eligible nahi hain"
            )
    
    # Format facility results
    if "facilities" in result and result["facilities"].get("status") == "success":
        facility = result["facilities"]
        facility_text = [
            "🏥 TAJWEEZ KARDAH HASPATAL:",
            f"Pehli Tarjeeh: {facility.get('name')}",
            f"Maqam: {facility.get('location')} - {facility.get('distance', 'Fasla naamalom')}"
        ]
        
        if facility.get("alternatives"):
            facility_text.append("\nDosre Haspatal:")
            for alt in facility["alternatives"]:
                facility_text.append(
                    f"- {alt.get('name')} - {alt.get('distance', 'Fasla naamalom')}"
                )
        sections.append("\n".join(facility_text))
    
    # Format reminders
    if "reminders" in result and result["reminders"].get("reminders"):
        reminder_text = ["⏰ YAAD DEHANIAN:"]
        for reminder in result["reminders"]["reminders"]:
            reminder_text.append(
                f"- {reminder.get('message', 'Koi paigham nahi')}"
            )
        sections.append("\n".join(reminder_text))
    
    # Add degraded mode warning if applicable
    if result.get("degraded_mode"):
        sections.append(
            "⚠️ Note: System backup mode par chal raha hai. "
            "Nataij mukhtasar ho sakte hain."
        )
    
    return "\n\n".join(sections)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)