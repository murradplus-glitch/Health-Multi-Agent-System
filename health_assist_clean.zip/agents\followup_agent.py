"""
Follow-up Agent that creates and manages patient reminders.
Uses Gemini for natural language reminder text when available.
"""

import os
import json
import logging
from typing import Dict, Any, List
import google.generativeai as genai
from datetime import datetime, timedelta
from mcp.client import MCPClient

class FollowupAgent:
    def __init__(self):
        # Setup logging
        log_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs')
        os.makedirs(log_dir, exist_ok=True)
        
        self.logger = logging.getLogger('followup_agent')
        self.logger.setLevel(logging.INFO)
        
        handler = logging.FileHandler(os.path.join(log_dir, 'followup_agent.log'))
        handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
        self.logger.addHandler(handler)

        # Initialize Gemini if possible
        try:
            genai.configure(api_key=os.getenv('GOOGLE_API_KEY'))
            self.model = genai.GenerativeModel('gemini-pro')
            self.gemini_enabled = True
        except Exception as e:
            self.logger.error(f"Failed to initialize Gemini: {e}")
            self.gemini_enabled = False

        # Initialize MCP client
        self.mcp = MCPClient()

    def _generate_reminder_text(self, context: Dict[str, Any]) -> str:
        """Generate human-friendly reminder text using Gemini or templates."""
        if self.gemini_enabled:
            try:
                prompt = f"""
                Generate a friendly, clear reminder message for a patient based on this context:
                {json.dumps(context, indent=2)}

                The message should:
                1. Be concise but warm
                2. Include key information (what/where/when)
                3. Use simple language
                4. Include any special instructions
                5. Be in both English and Urdu (Roman script)

                Focus on practical information the patient needs to remember.
                """

                response = self.model.generate_content(prompt)
                return response.text
            except Exception as e:
                self.logger.error(f"Gemini reminder generation failed: {e}")
                # Fall through to template-based generation

        # Template-based generation as fallback
        triage_ctx = context.get('triage_result') or {}
        severity = (triage_ctx.get('severity') or '').lower()
        facility_ctx = context.get('facility_choice') or {}
        facility_name = facility_ctx.get('name', 'the healthcare facility')

        templates = {
            'emergency': (
                f"URGENT: Please proceed to {facility_name} immediately. "
                f"Foran {facility_name} pohanchen."
            ),
            'hospital': (
                f"Important: Visit {facility_name} within 24 hours. "
                f"Zaroori: 24 ghante ke andar {facility_name} jayen."
            ),
            'routine': (
                f"Schedule your visit to {facility_name} at your earliest convenience. "
                f"{facility_name} ka daura jald se jald schedule karen."
            )
        }

        return templates.get(severity,
            f"Please visit {facility_name} for your healthcare needs. "
            f"Apni sehat ki dekh bhal ke liye {facility_name} tashrif le jayen."
        )

    def create_reminders(self, patient_id: str, triage_result: Dict[str, Any], 
                        facility_choice: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create 1-3 reminders based on patient's triage results and facility choice.
        
        Args:
            patient_id: Patient's ID/CNIC
            triage_result: Results from triage assessment
            facility_choice: Selected healthcare facility
            
        Returns:
            Dictionary containing created reminders and status
        """
        try:
            self.logger.info(f"Creating reminders for patient: {patient_id}")
            
            severity = (triage_result or {}).get('severity', '').lower()
            reminders = []
            
            # Context for reminder generation
            context = {
                "patient_id": patient_id,
                "triage_result": triage_result,
                "facility_choice": facility_choice
            }

            # Determine number and timing of reminders based on severity
            if severity == 'emergency':
                # Single immediate reminder for emergencies
                reminder = {
                    "patient_id": patient_id,
                    "type": "EMERGENCY",
                    "due_date": datetime.now().isoformat(),
                    "message": self._generate_reminder_text(context),
                    "priority": "high"
                }
                reminders.append(reminder)
                
            elif severity == 'hospital':
                # Two reminders - immediate and follow-up
                immediate = {
                    "patient_id": patient_id,
                    "type": "URGENT_VISIT",
                    "due_date": datetime.now().isoformat(),
                    "message": self._generate_reminder_text(context),
                    "priority": "high"
                }
                followup = {
                    "patient_id": patient_id,
                    "type": "FOLLOWUP",
                    "due_date": (datetime.now() + timedelta(days=1)).isoformat(),
                    "message": "Follow-up reminder: Please confirm if you've visited the facility. "
                             "Follow-up: Kya ap ne hospital visit ki?",
                    "priority": "medium"
                }
                reminders.extend([immediate, followup])
                
            else:
                # Regular reminder with normal priority
                reminder = {
                    "patient_id": patient_id,
                    "type": "REGULAR",
                    "due_date": (datetime.now() + timedelta(days=2)).isoformat(),
                    "message": self._generate_reminder_text(context),
                    "priority": "normal"
                }
                reminders.append(reminder)

            # Store reminders using MCP tool
            stored_reminders = []
            for reminder in reminders:
                try:
                    result = self.mcp.call_tool(
                        "reminder_store_tool",
                        reminder
                    )
                    if result and result.get('id'):
                        stored_reminders.append(result)
                    else:
                        self.logger.error(f"Failed to store reminder: {result}")
                except Exception as e:
                    self.logger.error(f"Error storing reminder: {e}")

            response = {
                "status": "success" if stored_reminders else "partial_success",
                "message": f"Created {len(stored_reminders)} reminders for patient {patient_id}",
                "reminders": stored_reminders,
                "severity": severity
            }

            self.logger.info(f"Reminder creation completed for {patient_id}")
            return response

        except Exception as e:
            error_msg = f"Error creating reminders: {str(e)}"
            self.logger.error(error_msg)
            return {
                "status": "error",
                "message": error_msg,
                "reminders": []
            }